/**
 * 
 */
package com.devglan.service;

import java.util.List;

import com.devglan.model.UserDetails;

public interface UserService {

	List<UserDetails> getUserDetails();

}
